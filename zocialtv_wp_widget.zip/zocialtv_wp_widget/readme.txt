=== ZOCIAL.tv - Trending Videos ===
Contributors: zocialtv
Donate link: http://zocial.tv/
Tags: zocialtv, zocial, zocial.tv, trending, videos, trending videos, youtube trending videos, hottest videos, youtube, facebook, twitter, widget, plugin, sidebar, video ranking
Requires at least: 2.6
Tested up to: 3.1
Stable tag: trunk

Show the hottest trending Videos shared on Twitter & Facebook, ranked by ZOCIAL.tv.
More thank 10MM videos in our database.

== Description ==

Show the hottest *Trending Videos shared on Twitter & Facebook*, ranked by [ZOCIAL.tv](http://zocial.tv "ZOCIAL.tv - your network tv").
This sidebar widget shows real-time ranked videos with title and accompanying image.
*Videos are saved on our database*, so you don't need to have space for all that information :)

Customize:
Choose "All" trending videos or show ranks by category
How many videos to show (paginate)
Background Color
Font size & color

== Installation ==
Step-by-Step instructions:

1- Upload the folder "zocialtv_wp_widget" to the /wp-content/plugins/ directory
2- Activate the plugin "ZOCIAL.tv - Trending Videos" online through the 'Plugins' menu in WordPress
3- Add the widget to your sidebar from Appearance->Widgets and configure the widget options

== Frequently Asked Questions ==

= Can I customize the ZOCIAL.tv widget? =

Yes you can, from ZOCIAL.tv Control panel, you can modify your setting and preview the widget.

== Screenshots ==

1. Example of ZOCIAL.tv Widget installed at sidebar. 
2. Example of ZOCIAL.tv Control Panel, where you can customize and preview your settings.

== Changelog ==

= 1.0 =
* First released version of ZOCIAL.tv Widget.

== Upgrade Notice==

= 1.0 =
* First released version of ZOCIAL.tv Widget.
